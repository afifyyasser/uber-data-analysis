# Uber Data Analysis

This project analyzes Uber ride data to extract insights and provide actionable recommendations.

## Project Description
The analysis includes data cleaning, exploration, visualization, and generating recommendations based on ride patterns, cancellations, and demand.

## Recommendations
See [recommendations.md](recommendations.md) for details.

## Requirements
All dependencies are listed in `requirements.txt`.

## Author
**Afifi yasser Afifi**  
📧 ofyasser977@gmail.com
