# Recommendations

- Increase cars from 17 till 23 in Airport.
- Increase cars from 04 till 10 in city.
- Add violations or increase costs on drivers with Cancelled trips > Completed.
- Add violations or increase costs on customers with Cancelled trips > Completed.
